package com.neon.dialer;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

/** The custom calling screen. The whole design lives in assets/incall.html. */
public class InCallActivity extends Activity implements CallManager.Listener {

    private WebView web;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private PowerManager.WakeLock prox;
    private boolean finishing = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#12050e"));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        web.addJavascriptInterface(new Bridge(this), "Phone");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                push();
            }
        });
        setContentView(web);
        web.loadUrl("file:///android_asset/incall.html");
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        push();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (!isDemo() && CallManager.count() == 0) {
            // Opened from the banner after the other person already hung up: nothing to show.
            try {
                ((android.app.NotificationManager) getSystemService(NOTIFICATION_SERVICE)).cancel(102);
            } catch (Exception ignored) {
            }
            android.widget.Toast.makeText(getApplicationContext(), "Call ended", android.widget.Toast.LENGTH_SHORT).show();
            finish();
            return;
        }
        CallManager.addListener(this);
        CallManager.uiVisible = true;
        CallManager.fire(); // pop-ups for this call are not needed while the call screen is open
        push();
    }

    @Override
    protected void onStop() {
        CallManager.removeListener(this);
        CallManager.uiVisible = false;
        CallManager.fire(); // left the call screen: bring the notification / pop-up back
        setProx(false);
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        setProx(false);
        if (web != null) {
            web.removeJavascriptInterface("Phone");
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }

    private boolean isDemo() {
        return getIntent() != null && getIntent().getBooleanExtra("demo", false);
    }

    @Override
    public void onChanged() {
        push();
        if (!isDemo() && CallManager.count() == 0 && !finishing) {
            finishing = true;
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if (CallManager.count() == 0) finish();
                    finishing = false;
                }
            }, 1600);
        }
        android.telecom.Call p = CallManager.primary();
        setProx(!isDemo() && p != null && p.getState() == android.telecom.Call.STATE_ACTIVE && CallManager.onEarpiece());
    }

    private void push() {
        if (web == null || isDemo()) return;
        String js = "window.onCall&&window.onCall(JSON.parse(" + JSONObject.quote(CallManager.json()) + "))";
        web.evaluateJavascript(js, null);
    }

    private void setProx(boolean on) {
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (prox == null && pm.isWakeLockLevelSupported(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK)) {
                prox = pm.newWakeLock(PowerManager.PROXIMITY_SCREEN_OFF_WAKE_LOCK, "neondialer:prox");
            }
            if (prox == null) return;
            if (on && !prox.isHeld()) prox.acquire();
            else if (!on && prox.isHeld()) prox.release();
        } catch (Exception ignored) {
        }
    }
}
