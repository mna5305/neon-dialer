package com.neon.dialer;

import android.Manifest;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.media.MediaRecorder;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.widget.Toast;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Call recorder for Android 8-14.
 *
 * Why recordings used to play back silent:
 *  1. MediaRecorder was started right after startForegroundService(), i.e. BEFORE the microphone
 *     foreground service was really running. On Android 11+ the system then silences the mic.
 *     -> Capture now starts from RecordService once startForeground() has completed.
 *  2. During a call many phones return all-zero frames for the chosen audio source.
 *     -> A watchdog measures the real input level. If it stays at zero it first turns the speaker
 *        on (so the mic can hear both sides) and then falls back to the next audio source.
 *  3. A recording that really stayed silent is now flagged (toast + badge in Records).
 */
public final class CallRecorder {
    private static final int SILENT_LEVEL = 8;      // getMaxAmplitude() below this == no audio
    private static final long WATCH_EVERY_MS = 600;
    private static final long SILENT_AFTER_MS = 2500;
    private static final int MAX_SWITCHES = 2;

    private static final Handler H = new Handler(Looper.getMainLooper());

    private static MediaRecorder rec;
    private static ParcelFileDescriptor pfd;
    private static Uri outUri;
    private static File outFile;
    private static String outName = "";
    private static long startedAt = 0;
    private static long attemptAt = 0;
    private static String lastError = "";
    private static String activeSourceName = "";

    private static boolean pending = false;
    private static String pendingLabel = "";
    private static Context appCtx;
    private static int[] sources = new int[0];
    private static int srcIdx = 0;
    private static int peak = 0;
    private static int switches = 0;
    private static boolean speakerForced = false;

    private CallRecorder() {
    }

    public static synchronized boolean isRecording() {
        return rec != null || pending;
    }

    public static synchronized long startedAt() {
        return startedAt;
    }

    public static synchronized String lastError() {
        return lastError;
    }

    public static synchronized String activeSource() {
        return activeSourceName;
    }

    /** Current input level. Every caller feeds the same peak tracker used by the silence watchdog. */
    public static synchronized int maxAmplitude() {
        if (rec == null) return 0;
        try {
            int v = rec.getMaxAmplitude();
            if (v > peak) peak = v;
            return v;
        } catch (Exception e) {
            return 0;
        }
    }

    /** Called by CallManager. Returns quickly; real capture starts in {@link #onServiceReady()}. */
    public static synchronized boolean start(Context ctx, String label) {
        if (rec != null || pending) return true;
        lastError = "";
        activeSourceName = "";
        if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            lastError = "Microphone permission needed";
            return false;
        }
        appCtx = ctx.getApplicationContext();
        pending = true;
        pendingLabel = label == null ? "" : label;
        RecordService.begin(appCtx);
        // Safety net: if the service never reports back, start anyway.
        H.removeCallbacks(fallbackStart);
        H.postDelayed(fallbackStart, 1500);
        return true;
    }

    private static final Runnable fallbackStart = new Runnable() {
        @Override
        public void run() {
            onServiceReady();
        }
    };

    /** RecordService calls this right after startForeground() so the mic is allowed to capture. */
    public static synchronized void onServiceReady() {
        H.removeCallbacks(fallbackStart);
        if (!pending || appCtx == null) return;
        pending = false;
        beginCapture(appCtx, pendingLabel);
    }

    private static void beginCapture(Context ctx, String label) {
        SharedPreferences prefs = ctx.getSharedPreferences("neon", Context.MODE_PRIVATE);
        String prefSrc = prefs.getString("recSource", "auto");
        boolean autoSpeaker = "1".equals(prefs.getString("autoSpeakerRec", "0"));
        switches = 0;
        speakerForced = false;
        startedAt = 0;

        if (autoSpeaker && !CallManager.speakerOn()) {
            try {
                CallManager.setSpeaker(true);
            } catch (Exception ignored) {
            }
        }

        try {
            AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            if (am != null && am.isMicrophoneMute() && !CallManager.muted) {
                am.setMicrophoneMute(false);
            }
        } catch (Exception ignored) {
        }

        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        String safe = label == null ? "" : label.replaceAll("[^A-Za-z0-9+ _-]", "").trim();
        if (safe.isEmpty()) safe = "Call";
        outName = "Call_" + safe.replace(' ', '_') + "_" + stamp + ".m4a";

        sources = pickSources(prefSrc);
        if (!tryFrom(ctx, 0)) {
            RecordService.end(ctx);
        }
    }

    private static int[] pickSources(String prefSrc) {
        if ("voice_call".equals(prefSrc)) {
            return new int[]{MediaRecorder.AudioSource.VOICE_CALL, MediaRecorder.AudioSource.VOICE_RECOGNITION, MediaRecorder.AudioSource.MIC};
        } else if ("voice_comm".equals(prefSrc)) {
            return new int[]{MediaRecorder.AudioSource.VOICE_COMMUNICATION, MediaRecorder.AudioSource.VOICE_RECOGNITION, MediaRecorder.AudioSource.MIC};
        } else if ("mic".equals(prefSrc)) {
            return new int[]{MediaRecorder.AudioSource.MIC, MediaRecorder.AudioSource.VOICE_RECOGNITION, MediaRecorder.AudioSource.VOICE_COMMUNICATION};
        }
        // auto: VOICE_CALL is skipped because on Android 10+ it "starts" fine but writes zero frames.
        return new int[]{MediaRecorder.AudioSource.VOICE_RECOGNITION, MediaRecorder.AudioSource.MIC, MediaRecorder.AudioSource.VOICE_COMMUNICATION};
    }

    /** Try the sources from index {@code from}; first one that starts wins. */
    private static boolean tryFrom(Context ctx, int from) {
        for (int i = from; i < sources.length; i++) {
            int src = sources[i];
            MediaRecorder r = null;
            try {
                openOutput(ctx, outName);
                r = Build.VERSION.SDK_INT >= 31 ? new MediaRecorder(ctx) : new MediaRecorder();
                r.setAudioSource(src);
                r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
                r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
                r.setAudioChannels(1);
                r.setAudioEncodingBitRate(128000);
                r.setAudioSamplingRate(44100);
                if (pfd != null) r.setOutputFile(pfd.getFileDescriptor());
                else r.setOutputFile(outFile.getAbsolutePath());
                r.prepare();
                r.start();
                try {
                    r.getMaxAmplitude(); // prime the meter
                } catch (Exception ignored) {
                }
                rec = r;
                srcIdx = i;
                peak = 0;
                attemptAt = System.currentTimeMillis();
                if (startedAt == 0) startedAt = attemptAt;
                activeSourceName = sourceName(src);
                lastError = "";
                H.removeCallbacks(watch);
                H.postDelayed(watch, WATCH_EVERY_MS);
                return true;
            } catch (Exception e) {
                lastError = String.valueOf(e.getMessage());
                try {
                    if (r != null) r.release();
                } catch (Exception ignored) {
                }
                cleanupFailed(ctx);
            }
        }
        return false;
    }

    private static final Runnable watch = new Runnable() {
        @Override
        public void run() {
            synchronized (CallRecorder.class) {
                if (rec == null) return;
                maxAmplitude();
                long el = System.currentTimeMillis() - attemptAt;
                if (peak < SILENT_LEVEL && el >= SILENT_AFTER_MS) {
                    if (!speakerForced) {
                        // Step 1: let the mic hear the other side through the loudspeaker.
                        speakerForced = true;
                        attemptAt = System.currentTimeMillis();
                        try {
                            if (!CallManager.speakerOn()) CallManager.setSpeaker(true);
                        } catch (Exception ignored) {
                        }
                    } else if (switches < MAX_SWITCHES && srcIdx + 1 < sources.length) {
                        // Step 2: this audio source is being muted by the phone, try the next one.
                        switches++;
                        switchSource();
                    }
                }
                H.postDelayed(this, WATCH_EVERY_MS);
            }
        }
    };

    private static void switchSource() {
        int prev = srcIdx;
        MediaRecorder old = rec;
        rec = null;
        try {
            old.stop();
        } catch (Exception ignored) {
        }
        try {
            old.reset();
        } catch (Exception ignored) {
        }
        try {
            old.release();
        } catch (Exception ignored) {
        }
        cleanupFailed(appCtx); // closes the descriptor and removes the silent file
        if (!tryFrom(appCtx, prev + 1)) {
            tryFrom(appCtx, prev);
        }
    }

    private static String sourceName(int src) {
        if (src == MediaRecorder.AudioSource.VOICE_CALL) return "Voice Line";
        if (src == MediaRecorder.AudioSource.VOICE_COMMUNICATION) return "Voice Comm";
        if (src == MediaRecorder.AudioSource.VOICE_RECOGNITION) return "Mic HD";
        return "Microphone";
    }

    private static void openOutput(Context ctx, String fname) throws Exception {
        pfd = null;
        outUri = null;
        outFile = null;
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Audio.Media.DISPLAY_NAME, fname);
            v.put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4");
            v.put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/CallRecordings");
            v.put(MediaStore.Audio.Media.IS_PENDING, 1);
            outUri = ctx.getContentResolver().insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, v);
            if (outUri == null) throw new Exception("Could not create the file");
            pfd = ctx.getContentResolver().openFileDescriptor(outUri, "rw");
            if (pfd == null) {
                pfd = ctx.getContentResolver().openFileDescriptor(outUri, "w");
            }
            if (pfd == null) throw new Exception("Could not open recording file descriptor");
        } else {
            File dir = new File(ctx.getExternalFilesDir(null), "CallRecordings");
            if (!dir.exists()) dir.mkdirs();
            outFile = new File(dir, fname);
        }
    }

    private static void cleanupFailed(Context ctx) {
        try {
            if (pfd != null) pfd.close();
        } catch (Exception ignored) {
        }
        pfd = null;
        try {
            if (outUri != null) ctx.getContentResolver().delete(outUri, null, null);
        } catch (Exception ignored) {
        }
        try {
            if (outFile != null) outFile.delete();
        } catch (Exception ignored) {
        }
        outUri = null;
        outFile = null;
    }

    public static synchronized void stop(Context ctx) {
        H.removeCallbacks(watch);
        H.removeCallbacks(fallbackStart);
        if (rec == null) {
            if (pending) {
                pending = false;
                if (ctx != null) RecordService.end(ctx);
            }
            return;
        }
        maxAmplitude();
        boolean silent = peak < SILENT_LEVEL && (System.currentTimeMillis() - attemptAt) > 3000;
        String name = outName;

        try {
            rec.stop();
        } catch (Exception ignored) {
        }
        try {
            rec.reset();
        } catch (Exception ignored) {
        }
        try {
            rec.release();
        } catch (Exception ignored) {
        }
        rec = null;
        try {
            if (pfd != null) {
                try {
                    pfd.getFileDescriptor().sync();
                } catch (Exception ignored) {
                }
                pfd.close();
            }
        } catch (Exception ignored) {
        }
        pfd = null;

        if (Build.VERSION.SDK_INT >= 29 && outUri != null && ctx != null) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Audio.Media.IS_PENDING, 0);
            try {
                ctx.getContentResolver().update(outUri, v, null, null);
            } catch (Exception ignored) {
            }
        } else if (outFile != null && outFile.exists() && ctx != null) {
            try {
                MediaScannerConnection.scanFile(ctx, new String[]{outFile.getAbsolutePath()}, new String[]{"audio/mp4"}, null);
            } catch (Exception ignored) {
            }
        }

        outUri = null;
        outFile = null;
        startedAt = 0;
        activeSourceName = "";
        if (ctx != null) {
            if (silent) {
                final Context app = ctx.getApplicationContext();
                app.getSharedPreferences("neon", Context.MODE_PRIVATE).edit().putBoolean("silent_" + name, true).apply();
                H.post(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(app, "No sound was captured in this recording. Turn on Auto-Speaker or change the Recording source in Settings.", Toast.LENGTH_LONG).show();
                    }
                });
            }
            RecordService.end(ctx);
        }
    }
}
