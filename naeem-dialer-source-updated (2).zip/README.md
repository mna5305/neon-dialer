# Naeem Dialer — Custom Edition

A custom-designed Android phone dialer, smart call history manager, in-app contact manager, and custom calling screen built for **Naeem**.

## Key Features
- **Fixed Call Recording & In-App Player**: Uses HD microphone capture (`VOICE_RECOGNITION` / `MIC` fallback) with foreground microphone service started before capture, AudioAttributes (`USAGE_MEDIA`), volume safeguard, and seekable audio playback bar.
- **Smart Recents & Call History Sheet**: Filter by All / Missed / Incoming / Outgoing, grouped numbers with call counts, and tapping any row opens a complete Call History timeline + stats + instant Call/WhatsApp/Save actions.
- **Built-In In-App Contact Manager**: Add, edit, star, and delete contacts directly inside Naeem Dialer (with Gmail vs Device save location picker) without leaving to the stock Contacts app.
- **Contact Sync Breakdown**: Inspect how many contacts are synced from each Gmail account vs Device storage vs SIM.
- **WhatsApp Direct (No Saving Needed)**: Message any unsaved number on WhatsApp directly from the Keypad, Recents, or the WhatsApp Direct sheet with quick templates.
- **Custom Calling Screen & Naeem Branding**: 4 themes (`Neon Glass`, `AMOLED Pure`, `Aurora Prism`, `Naeem Gold`), accent color picker, live recording mic meter, and Naeem Edition branding & watermarks.

## Build Android APK (GitHub Actions)
1. Push this project (`android/` and `.github/`) to your GitHub repository (`main` branch).
2. Open the **Actions** tab — **Build Android APK** builds `app-debug.apk`.
3. Download the `naeem-dialer-apk` artifact, unzip, and install on Android.
