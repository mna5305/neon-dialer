package com.neon.dialer;

import android.Manifest;
import android.accounts.Account;
import android.accounts.AccountManager;
import android.app.Activity;
import android.app.role.RoleManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentProviderOperation;
import android.content.ContentProviderResult;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.media.audiofx.LoudnessEnhancer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.telecom.TelecomManager;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/**
 * Native Android <-> HTML bridge for Naeem Dialer.
 */
public class Bridge {
    private static final String PREFS = "neon";
    private final Activity act;
    public WebView web;

    public Bridge(Activity a) {
        this.act = a;
    }

    private SharedPreferences prefs() {
        return act.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    private boolean has(String p) {
        return act.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    private void ui(Runnable r) {
        act.runOnUiThread(r);
    }

    /* ------------------------------------------------------------------ */
    /* Preferences + UI helpers                                            */
    /* ------------------------------------------------------------------ */

    @JavascriptInterface
    public String getPref(String k, String d) {
        return prefs().getString(k, d);
    }

    @JavascriptInterface
    public void setPref(String k, String v) {
        prefs().edit().putString(k, v).apply();
    }

    @JavascriptInterface
    public void toast(final String m) {
        ui(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(act, m, Toast.LENGTH_SHORT).show();
            }
        });
    }

    /* ------------------------------------------------------------------ */
    /* Permissions + default phone app                                     */
    /* ------------------------------------------------------------------ */

    @JavascriptInterface
    public String hasPerms() {
        try {
            JSONObject o = new JSONObject();
            o.put("contacts", has(Manifest.permission.READ_CONTACTS));
            o.put("writeContacts", has(Manifest.permission.WRITE_CONTACTS));
            o.put("log", has(Manifest.permission.READ_CALL_LOG));
            o.put("phone", has(Manifest.permission.CALL_PHONE) && has(Manifest.permission.READ_PHONE_STATE));
            o.put("def", isDefault());
            return o.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    @JavascriptInterface
    public void askPerms() {
        ui(new Runnable() {
            @Override
            public void run() {
                ArrayList<String> l = new ArrayList<>();
                String[] all = {
                        Manifest.permission.READ_CONTACTS,
                        Manifest.permission.WRITE_CONTACTS,
                        Manifest.permission.GET_ACCOUNTS,
                        Manifest.permission.READ_CALL_LOG,
                        Manifest.permission.WRITE_CALL_LOG,
                        Manifest.permission.CALL_PHONE,
                        Manifest.permission.READ_PHONE_STATE,
                        Manifest.permission.ANSWER_PHONE_CALLS
                };
                for (String p : all) {
                    if (!has(p)) l.add(p);
                }
                if (Build.VERSION.SDK_INT >= 33 && !has(Manifest.permission.POST_NOTIFICATIONS)) {
                    l.add(Manifest.permission.POST_NOTIFICATIONS);
                }
                if (!l.isEmpty()) act.requestPermissions(l.toArray(new String[0]), 77);
            }
        });
    }

    @JavascriptInterface
    public boolean isDefault() {
        try {
            TelecomManager tm = act.getSystemService(TelecomManager.class);
            return tm != null && act.getPackageName().equals(tm.getDefaultDialerPackage());
        } catch (Exception e) {
            return false;
        }
    }

    @JavascriptInterface
    public void requestDefault() {
        ui(new Runnable() {
            @Override
            public void run() {
                try {
                    if (Build.VERSION.SDK_INT >= 29) {
                        RoleManager rm = act.getSystemService(RoleManager.class);
                        if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_DIALER)) {
                            act.startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER), 1001);
                            return;
                        }
                    }
                    Intent i = new Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER);
                    i.putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, act.getPackageName());
                    act.startActivityForResult(i, 1001);
                } catch (Exception e) {
                    Toast.makeText(act, "Could not open the default app picker", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    /* ------------------------------------------------------------------ */
    /* Placing calls + WhatsApp Direct + opening things                    */
    /* ------------------------------------------------------------------ */

    @JavascriptInterface
    public void call(final String num) {
        ui(new Runnable() {
            @Override
            public void run() {
                if (!has(Manifest.permission.CALL_PHONE)) {
                    act.requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, 78);
                    return;
                }
                try {
                    TelecomManager tm = act.getSystemService(TelecomManager.class);
                    tm.placeCall(Uri.fromParts("tel", num, null), new Bundle());
                } catch (Exception e) {
                    Toast.makeText(act, "Could not place the call", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    @JavascriptInterface
    public void open(final String url) {
        ui(new Runnable() {
            @Override
            public void run() {
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    act.startActivity(i);
                } catch (Exception e) {
                    Toast.makeText(act, "No app found for this action", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @JavascriptInterface
    public void openWhatsApp(final String rawNum, final String message) {
        ui(new Runnable() {
            @Override
            public void run() {
                String clean = normalizeWaNumber(rawNum);
                if (clean.isEmpty()) {
                    Toast.makeText(act, "Enter a valid phone number", Toast.LENGTH_SHORT).show();
                    return;
                }
                String msgParam = (message != null && !message.trim().isEmpty())
                        ? "&text=" + Uri.encode(message.trim())
                        : "";
                String waUri = "whatsapp://send?phone=" + clean + msgParam;
                String webUri = "https://wa.me/" + clean + (msgParam.isEmpty() ? "" : "?" + msgParam.substring(1));

                String[] pkgs = {"com.whatsapp", "com.whatsapp.w4b"};
                for (String pkg : pkgs) {
                    try {
                        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(waUri));
                        i.setPackage(pkg);
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        act.startActivity(i);
                        return;
                    } catch (Exception ignored) {
                    }
                }
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(webUri));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    act.startActivity(i);
                } catch (Exception e) {
                    Toast.makeText(act, "WhatsApp is not installed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private String normalizeWaNumber(String raw) {
        if (raw == null) return "";
        String t = raw.trim();
        String d = t.replaceAll("\\D", "");
        if (d.isEmpty()) return "";
        String cc = prefs().getString("cc", "92").replaceAll("\\D", "");
        if (cc.isEmpty()) cc = "92";
        if (t.startsWith("+")) return d;
        if (d.startsWith("00")) return d.substring(2);
        if (d.startsWith("0")) return cc + d.substring(1);
        return d.length() <= 10 ? cc + d : d;
    }

    @JavascriptInterface
    public void addContact(final String name, final String num) {
        ui(new Runnable() {
            @Override
            public void run() {
                try {
                    Intent i = new Intent(Intent.ACTION_INSERT, ContactsContract.Contacts.CONTENT_URI);
                    if (name != null && !name.isEmpty()) i.putExtra(ContactsContract.Intents.Insert.NAME, name);
                    if (num != null && !num.isEmpty()) i.putExtra(ContactsContract.Intents.Insert.PHONE, num);
                    act.startActivity(i);
                } catch (Exception e) {
                    Toast.makeText(act, "Contacts app not available", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @JavascriptInterface
    public void openContact(final String id) {
        ui(new Runnable() {
            @Override
            public void run() {
                try {
                    Uri u = Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_URI, id);
                    act.startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception e) {
                    Toast.makeText(act, "Could not open contact", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @JavascriptInterface
    public void openDialer() {
        ui(new Runnable() {
            @Override
            public void run() {
                Intent i = new Intent(act, MainActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                act.startActivity(i);
            }
        });
    }

    @JavascriptInterface
    public void previewCall(final String mode) {
        ui(new Runnable() {
            @Override
            public void run() {
                Intent i = new Intent(act, InCallActivity.class);
                i.putExtra("demo", true);
                i.putExtra("mode", mode);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                act.startActivity(i);
            }
        });
    }

    /* ------------------------------------------------------------------ */
    /* Contacts + Account Sync Stats + In-App Contact CRUD                 */
    /* ------------------------------------------------------------------ */

    private static String classifyAccount(String type, String name) {
        String t = type == null ? "" : type.toLowerCase();
        String n = name == null ? "" : name.toLowerCase();
        if (t.contains("google") || n.contains("@gmail.com")) return "gmail";
        if (t.contains("whatsapp")) return "whatsapp";
        if (t.contains("sim") || n.contains("sim")) return "sim";
        if (t.isEmpty() || t.contains("local") || t.contains("phone") || t.contains("device") || t.equals("vnd.sec.contact.phone")) {
            return "device";
        }
        return "other";
    }

    private static String friendlyAccountLabel(String type, String name) {
        String cat = classifyAccount(type, name);
        if ("gmail".equals(cat)) return (name == null || name.isEmpty()) ? "Google Account" : name;
        if ("device".equals(cat)) return "Device / Phone Storage";
        if ("sim".equals(cat)) return (name == null || name.isEmpty()) ? "SIM Card" : "SIM (" + name + ")";
        if ("whatsapp".equals(cat)) return "WhatsApp Contacts";
        return (name == null || name.isEmpty()) ? (type == null ? "Other" : type) : name;
    }

    @JavascriptInterface
    public String getSyncStats() {
        JSONObject res = new JSONObject();
        JSONArray accArr = new JSONArray();
        if (!has(Manifest.permission.READ_CONTACTS)) {
            try {
                res.put("total", 0);
                res.put("gmailTotal", 0);
                res.put("deviceTotal", 0);
                res.put("simTotal", 0);
                res.put("otherTotal", 0);
                res.put("accounts", accArr);
            } catch (Exception ignored) {
            }
            return res.toString();
        }

        Map<String, Set<Long>> bucketIds = new LinkedHashMap<>();
        Map<String, String[]> bucketMeta = new LinkedHashMap<>();
        Set<Long> allContactIds = new HashSet<>();
        Set<Long> gmailIds = new HashSet<>();
        Set<Long> deviceIds = new HashSet<>();
        Set<Long> simIds = new HashSet<>();
        Set<Long> otherIds = new HashSet<>();

        // Seed Google accounts from AccountManager so even 0-contact Gmail accounts show up
        try {
            AccountManager am = AccountManager.get(act);
            Account[] gAccs = am.getAccountsByType("com.google");
            for (Account a : gAccs) {
                String key = "com.google|" + a.name;
                bucketIds.putIfAbsent(key, new HashSet<Long>());
                bucketMeta.putIfAbsent(key, new String[]{"com.google", a.name});
            }
        } catch (Exception ignored) {
        }

        Cursor c = null;
        try {
            String[] proj = {
                    ContactsContract.RawContacts.CONTACT_ID,
                    ContactsContract.RawContacts.ACCOUNT_TYPE,
                    ContactsContract.RawContacts.ACCOUNT_NAME
            };
            c = act.getContentResolver().query(
                    ContactsContract.RawContacts.CONTENT_URI,
                    proj,
                    ContactsContract.RawContacts.DELETED + "=0",
                    null,
                    null
            );
            if (c != null) {
                while (c.moveToNext()) {
                    long cid = c.getLong(0);
                    if (cid <= 0) continue;
                    String type = c.getString(1);
                    String name = c.getString(2);
                    if (type == null) type = "";
                    if (name == null) name = "";

                    allContactIds.add(cid);
                    String cat = classifyAccount(type, name);
                    if ("gmail".equals(cat)) gmailIds.add(cid);
                    else if ("device".equals(cat)) deviceIds.add(cid);
                    else if ("sim".equals(cat)) simIds.add(cid);
                    else otherIds.add(cid);

                    String key = ("device".equals(cat)) ? "device|local" : (type + "|" + name);
                    Set<Long> set = bucketIds.get(key);
                    if (set == null) {
                        set = new HashSet<>();
                        bucketIds.put(key, set);
                        bucketMeta.put(key, "device".equals(cat) ? new String[]{"", "Device"} : new String[]{type, name});
                    }
                    set.add(cid);
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }

        try {
            for (Map.Entry<String, Set<Long>> e : bucketIds.entrySet()) {
                String[] meta = bucketMeta.get(e.getKey());
                String type = meta[0];
                String name = meta[1];
                String cat = classifyAccount(type, name);
                JSONObject o = new JSONObject();
                o.put("type", type);
                o.put("name", name);
                o.put("category", cat);
                o.put("label", friendlyAccountLabel(type, name));
                o.put("count", e.getValue().size());
                accArr.put(o);
            }
            res.put("total", allContactIds.size());
            res.put("gmailTotal", gmailIds.size());
            res.put("deviceTotal", deviceIds.size());
            res.put("simTotal", simIds.size());
            res.put("otherTotal", otherIds.size());
            res.put("accounts", accArr);
        } catch (Exception ignored) {
        }
        return res.toString();
    }

    @JavascriptInterface
    public String getContacts() {
        JSONArray arr = new JSONArray();
        if (!has(Manifest.permission.READ_CONTACTS)) return arr.toString();

        // Map contactId -> sync source category & account label
        Map<Long, String> srcCat = new HashMap<>();
        Map<Long, String> srcLbl = new HashMap<>();
        Cursor rc = null;
        try {
            rc = act.getContentResolver().query(
                    ContactsContract.RawContacts.CONTENT_URI,
                    new String[]{ContactsContract.RawContacts.CONTACT_ID, ContactsContract.RawContacts.ACCOUNT_TYPE, ContactsContract.RawContacts.ACCOUNT_NAME},
                    ContactsContract.RawContacts.DELETED + "=0",
                    null, null
            );
            if (rc != null) {
                while (rc.moveToNext()) {
                    long cid = rc.getLong(0);
                    String type = rc.getString(1);
                    String name = rc.getString(2);
                    String cat = classifyAccount(type, name);
                    // Prefer gmail over device/whatsapp if merged
                    String prev = srcCat.get(cid);
                    if (prev == null || "gmail".equals(cat)) {
                        srcCat.put(cid, cat);
                        srcLbl.put(cid, friendlyAccountLabel(type, name));
                    }
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (rc != null) rc.close();
        }

        // Map contactId -> primary email & note
        Map<Long, String> emailMap = new HashMap<>();
        Cursor ec = null;
        try {
            ec = act.getContentResolver().query(
                    ContactsContract.CommonDataKinds.Email.CONTENT_URI,
                    new String[]{ContactsContract.CommonDataKinds.Email.CONTACT_ID, ContactsContract.CommonDataKinds.Email.ADDRESS},
                    null, null, null
            );
            if (ec != null) {
                while (ec.moveToNext()) {
                    long cid = ec.getLong(0);
                    String em = ec.getString(1);
                    if (em != null && !em.isEmpty() && !emailMap.containsKey(cid)) {
                        emailMap.put(cid, em);
                    }
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (ec != null) ec.close();
        }

        Map<Long, String> noteMap = new HashMap<>();
        Cursor nc = null;
        try {
            nc = act.getContentResolver().query(
                    ContactsContract.Data.CONTENT_URI,
                    new String[]{ContactsContract.Data.CONTACT_ID, ContactsContract.CommonDataKinds.Note.NOTE},
                    ContactsContract.Data.MIMETYPE + "=?",
                    new String[]{ContactsContract.CommonDataKinds.Note.CONTENT_ITEM_TYPE},
                    null
            );
            if (nc != null) {
                while (nc.moveToNext()) {
                    long cid = nc.getLong(0);
                    String nt = nc.getString(1);
                    if (nt != null && !nt.isEmpty() && !noteMap.containsKey(cid)) {
                        noteMap.put(cid, nt);
                    }
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (nc != null) nc.close();
        }

        String[] proj = {
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER,
                ContactsContract.Contacts.STARRED
        };
        Cursor c = null;
        try {
            c = act.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, proj, null, null,
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE NOCASE ASC");
            if (c != null) {
                Set<String> seen = new HashSet<>();
                while (c.moveToNext()) {
                    long cid = c.getLong(0);
                    String num = c.getString(2);
                    if (num == null) continue;
                    String key = cid + ":" + num.replaceAll("\\D", "");
                    if (!seen.add(key)) continue;
                    JSONObject o = new JSONObject();
                    o.put("id", cid);
                    o.put("name", c.getString(1) == null ? "" : c.getString(1));
                    o.put("num", num);
                    o.put("star", c.getInt(3) == 1);
                    o.put("email", emailMap.getOrDefault(cid, ""));
                    o.put("note", noteMap.getOrDefault(cid, ""));
                    o.put("src", srcCat.getOrDefault(cid, "device"));
                    o.put("srcLabel", srcLbl.getOrDefault(cid, "Device / Phone Storage"));
                    arr.put(o);
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return arr.toString();
    }

    @JavascriptInterface
    public String saveContact(String contactId, String name, String num, String email, String note,
                              String accountName, String accountType, boolean starred) {
        JSONObject out = new JSONObject();
        try {
            if (!has(Manifest.permission.WRITE_CONTACTS)) {
                ui(new Runnable() {
                    @Override
                    public void run() {
                        act.requestPermissions(new String[]{Manifest.permission.WRITE_CONTACTS, Manifest.permission.READ_CONTACTS}, 81);
                    }
                });
                out.put("ok", false);
                out.put("needPerm", true);
                out.put("error", "Allow Contacts write permission");
                return out.toString();
            }

            ContentResolver cr = act.getContentResolver();
            String cleanName = name == null ? "" : name.trim();
            String cleanNum = num == null ? "" : num.trim();
            String cleanEmail = email == null ? "" : email.trim();
            String cleanNote = note == null ? "" : note.trim();

            if (cleanNum.isEmpty()) {
                out.put("ok", false);
                out.put("error", "Phone number is required");
                return out.toString();
            }

            if (contactId != null && !contactId.trim().isEmpty()) {
                long cid = Long.parseLong(contactId.trim());
                long rawId = findRawContactId(cr, cid);
                if (rawId <= 0) {
                    out.put("ok", false);
                    out.put("error", "Contact record not found");
                    return out.toString();
                }

                // Update Starred on Contacts table
                ContentValues starVals = new ContentValues();
                starVals.put(ContactsContract.Contacts.STARRED, starred ? 1 : 0);
                cr.update(ContactsContract.Contacts.CONTENT_URI, starVals, ContactsContract.Contacts._ID + "=?", new String[]{String.valueOf(cid)});

                // Update or insert Name
                upsertData(cr, rawId, ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE,
                        ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, cleanName.isEmpty() ? cleanNum : cleanName);

                // Update or insert Phone
                upsertPhone(cr, rawId, cleanNum);

                // Update or insert Email
                if (!cleanEmail.isEmpty()) {
                    upsertData(cr, rawId, ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE,
                            ContactsContract.CommonDataKinds.Email.ADDRESS, cleanEmail);
                }
                // Update or insert Note
                if (!cleanNote.isEmpty()) {
                    upsertData(cr, rawId, ContactsContract.CommonDataKinds.Note.CONTENT_ITEM_TYPE,
                            ContactsContract.CommonDataKinds.Note.NOTE, cleanNote);
                }

                out.put("ok", true);
                out.put("id", cid);
                return out.toString();
            } else {
                ArrayList<ContentProviderOperation> ops = new ArrayList<>();
                ContentProviderOperation.Builder rawB = ContentProviderOperation.newInsert(ContactsContract.RawContacts.CONTENT_URI);
                if (accountType != null && !accountType.trim().isEmpty() && accountName != null && !accountName.trim().isEmpty()) {
                    rawB.withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, accountType.trim());
                    rawB.withValue(ContactsContract.RawContacts.ACCOUNT_NAME, accountName.trim());
                } else {
                    rawB.withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, null);
                    rawB.withValue(ContactsContract.RawContacts.ACCOUNT_NAME, null);
                }
                ops.add(rawB.build());

                ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                        .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
                        .withValue(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, cleanName.isEmpty() ? cleanNum : cleanName)
                        .build());

                ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                        .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                        .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE)
                        .withValue(ContactsContract.CommonDataKinds.Phone.NUMBER, cleanNum)
                        .withValue(ContactsContract.CommonDataKinds.Phone.TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE)
                        .build());

                if (!cleanEmail.isEmpty()) {
                    ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                            .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                            .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Email.CONTENT_ITEM_TYPE)
                            .withValue(ContactsContract.CommonDataKinds.Email.ADDRESS, cleanEmail)
                            .withValue(ContactsContract.CommonDataKinds.Email.TYPE, ContactsContract.CommonDataKinds.Email.TYPE_HOME)
                            .build());
                }

                if (!cleanNote.isEmpty()) {
                    ops.add(ContentProviderOperation.newInsert(ContactsContract.Data.CONTENT_URI)
                            .withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
                            .withValue(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Note.CONTENT_ITEM_TYPE)
                            .withValue(ContactsContract.CommonDataKinds.Note.NOTE, cleanNote)
                            .build());
                }

                ContentProviderResult[] res = cr.applyBatch(ContactsContract.AUTHORITY, ops);
                long newRawId = (res.length > 0 && res[0].uri != null) ? ContentUris.parseId(res[0].uri) : -1;
                long newCid = findContactIdFromRaw(cr, newRawId);
                if (starred && newCid > 0) {
                    ContentValues sv = new ContentValues();
                    sv.put(ContactsContract.Contacts.STARRED, 1);
                    cr.update(ContactsContract.Contacts.CONTENT_URI, sv, ContactsContract.Contacts._ID + "=?", new String[]{String.valueOf(newCid)});
                }
                out.put("ok", true);
                out.put("id", newCid);
                return out.toString();
            }
        } catch (Exception e) {
            try {
                out.put("ok", false);
                out.put("error", String.valueOf(e.getMessage()));
            } catch (Exception ignored) {
            }
            return out.toString();
        }
    }

    private long findRawContactId(ContentResolver cr, long contactId) {
        Cursor c = null;
        try {
            c = cr.query(ContactsContract.RawContacts.CONTENT_URI,
                    new String[]{ContactsContract.RawContacts._ID},
                    ContactsContract.RawContacts.CONTACT_ID + "=? AND " + ContactsContract.RawContacts.DELETED + "=0",
                    new String[]{String.valueOf(contactId)}, null);
            if (c != null && c.moveToFirst()) return c.getLong(0);
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return -1;
    }

    private long findContactIdFromRaw(ContentResolver cr, long rawId) {
        if (rawId <= 0) return -1;
        Cursor c = null;
        try {
            c = cr.query(ContactsContract.RawContacts.CONTENT_URI,
                    new String[]{ContactsContract.RawContacts.CONTACT_ID},
                    ContactsContract.RawContacts._ID + "=?",
                    new String[]{String.valueOf(rawId)}, null);
            if (c != null && c.moveToFirst()) return c.getLong(0);
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return -1;
    }

    private void upsertData(ContentResolver cr, long rawId, String mime, String col, String val) {
        ContentValues v = new ContentValues();
        v.put(col, val);
        int updated = cr.update(ContactsContract.Data.CONTENT_URI, v,
                ContactsContract.Data.RAW_CONTACT_ID + "=? AND " + ContactsContract.Data.MIMETYPE + "=?",
                new String[]{String.valueOf(rawId), mime});
        if (updated == 0) {
            v.put(ContactsContract.Data.RAW_CONTACT_ID, rawId);
            v.put(ContactsContract.Data.MIMETYPE, mime);
            cr.insert(ContactsContract.Data.CONTENT_URI, v);
        }
    }

    private void upsertPhone(ContentResolver cr, long rawId, String num) {
        ContentValues v = new ContentValues();
        v.put(ContactsContract.CommonDataKinds.Phone.NUMBER, num);
        int updated = cr.update(ContactsContract.Data.CONTENT_URI, v,
                ContactsContract.Data.RAW_CONTACT_ID + "=? AND " + ContactsContract.Data.MIMETYPE + "=?",
                new String[]{String.valueOf(rawId), ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE});
        if (updated == 0) {
            v.put(ContactsContract.Data.RAW_CONTACT_ID, rawId);
            v.put(ContactsContract.Data.MIMETYPE, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE);
            v.put(ContactsContract.CommonDataKinds.Phone.TYPE, ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE);
            cr.insert(ContactsContract.Data.CONTENT_URI, v);
        }
    }

    @JavascriptInterface
    public boolean setContactStar(String contactId, boolean starred) {
        if (!has(Manifest.permission.WRITE_CONTACTS) || contactId == null || contactId.isEmpty()) return false;
        try {
            ContentValues v = new ContentValues();
            v.put(ContactsContract.Contacts.STARRED, starred ? 1 : 0);
            int u = act.getContentResolver().update(
                    ContactsContract.Contacts.CONTENT_URI, v,
                    ContactsContract.Contacts._ID + "=?", new String[]{contactId});
            return u > 0;
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Keeps one contact for a number that is saved under several names.
     * The duplicate number is removed from the other contacts (a contact left without any number is
     * deleted) and the kept contact gets the chosen name.
     */
    @JavascriptInterface
    public String mergeDuplicates(String keepCid, String newName, String dropCids, String num) {
        JSONObject out = new JSONObject();
        try {
            if (!has(Manifest.permission.WRITE_CONTACTS)) {
                out.put("ok", false);
                out.put("error", "Allow Contacts permission first");
                return out.toString();
            }
            ContentResolver cr = act.getContentResolver();
            String d = num == null ? "" : num.replaceAll("\\D", "");
            if (d.length() > 9) d = d.substring(d.length() - 9);
            int removed = 0, deleted = 0;
            if (dropCids != null && !dropCids.isEmpty()) {
                for (String cid : dropCids.split(",")) {
                    if (cid.isEmpty() || cid.equals(keepCid)) continue;
                    int phones = 0;
                    ArrayList<Long> kill = new ArrayList<>();
                    Cursor c = cr.query(ContactsContract.Data.CONTENT_URI,
                            new String[]{ContactsContract.Data._ID, ContactsContract.CommonDataKinds.Phone.NUMBER},
                            ContactsContract.Data.CONTACT_ID + "=? AND " + ContactsContract.Data.MIMETYPE + "=?",
                            new String[]{cid, ContactsContract.CommonDataKinds.Phone.CONTENT_ITEM_TYPE}, null);
                    if (c != null) {
                        try {
                            while (c.moveToNext()) {
                                phones++;
                                String p = c.getString(1);
                                String pd = p == null ? "" : p.replaceAll("\\D", "");
                                if (pd.length() > 9) pd = pd.substring(pd.length() - 9);
                                if (pd.equals(d)) kill.add(c.getLong(0));
                            }
                        } finally {
                            c.close();
                        }
                    }
                    for (long id : kill) {
                        removed += cr.delete(ContentUris.withAppendedId(ContactsContract.Data.CONTENT_URI, id), null, null);
                    }
                    if (phones - kill.size() <= 0) {
                        cr.delete(ContactsContract.RawContacts.CONTENT_URI,
                                ContactsContract.RawContacts.CONTACT_ID + "=?", new String[]{cid});
                        deleted++;
                    }
                }
            }
            if (newName != null && !newName.trim().isEmpty() && keepCid != null && !keepCid.isEmpty()) {
                ContentValues v = new ContentValues();
                v.put(ContactsContract.CommonDataKinds.StructuredName.DISPLAY_NAME, newName.trim());
                cr.update(ContactsContract.Data.CONTENT_URI, v,
                        ContactsContract.Data.CONTACT_ID + "=? AND " + ContactsContract.Data.MIMETYPE + "=?",
                        new String[]{keepCid, ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE});
            }
            out.put("ok", true);
            out.put("removed", removed);
            out.put("deleted", deleted);
        } catch (Exception e) {
            try {
                out.put("ok", false);
                out.put("error", String.valueOf(e.getMessage()));
            } catch (Exception ignored) {
            }
        }
        return out.toString();
    }

    @JavascriptInterface
    public boolean deleteContact(String contactId) {
        if (!has(Manifest.permission.WRITE_CONTACTS) || contactId == null || contactId.isEmpty()) return false;
        try {
            int d = act.getContentResolver().delete(
                    ContactsContract.RawContacts.CONTENT_URI,
                    ContactsContract.RawContacts.CONTACT_ID + "=?", new String[]{contactId});
            return d > 0;
        } catch (Exception e) {
            return false;
        }
    }

    @JavascriptInterface
    public String getRecents() {
        JSONArray arr = new JSONArray();
        if (!has(Manifest.permission.READ_CALL_LOG)) return arr.toString();
        String[] proj = {
                CallLog.Calls._ID,
                CallLog.Calls.NUMBER,
                CallLog.Calls.CACHED_NAME,
                CallLog.Calls.TYPE,
                CallLog.Calls.DATE,
                CallLog.Calls.DURATION,
                CallLog.Calls.CACHED_NUMBER_LABEL
        };
        Cursor c = null;
        try {
            Bundle q = new Bundle();
            q.putInt(ContentResolver.QUERY_ARG_LIMIT, 400);
            q.putStringArray(ContentResolver.QUERY_ARG_SORT_COLUMNS, new String[]{CallLog.Calls.DATE});
            q.putInt(ContentResolver.QUERY_ARG_SORT_DIRECTION, ContentResolver.QUERY_SORT_DIRECTION_DESCENDING);
            c = act.getContentResolver().query(CallLog.Calls.CONTENT_URI, proj, q, null);
            if (c != null) {
                while (c.moveToNext()) {
                    JSONObject o = new JSONObject();
                    o.put("id", c.getLong(0));
                    o.put("number", c.getString(1) == null ? "" : c.getString(1));
                    o.put("name", c.getString(2) == null ? "" : c.getString(2));
                    o.put("type", c.getInt(3));
                    o.put("date", c.getLong(4));
                    o.put("duration", c.getLong(5));
                    o.put("label", c.getString(6) == null ? "" : c.getString(6));
                    arr.put(o);
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return arr.toString();
    }

    /** Deletes single call-log entries by id (comma separated). Only the call log is touched, never contacts. */
    @JavascriptInterface
    public int deleteRecentIds(String csv) {
        if (!has(Manifest.permission.WRITE_CALL_LOG) || csv == null || csv.trim().isEmpty()) return -1;
        int total = 0;
        try {
            String[] parts = csv.split(",");
            for (String part : parts) {
                String t = part.trim();
                if (t.isEmpty()) continue;
                long id;
                try {
                    id = Long.parseLong(t);
                } catch (NumberFormatException e) {
                    continue;
                }
                total += act.getContentResolver().delete(CallLog.Calls.CONTENT_URI, CallLog.Calls._ID + "=?", new String[]{String.valueOf(id)});
            }
        } catch (Exception e) {
            return total;
        }
        return total;
    }

    /** Clears the whole call log. Contacts are not touched. */
    @JavascriptInterface
    public int clearAllRecents() {
        if (!has(Manifest.permission.WRITE_CALL_LOG)) return -1;
        try {
            return act.getContentResolver().delete(CallLog.Calls.CONTENT_URI, null, null);
        } catch (Exception e) {
            return -1;
        }
    }

    @JavascriptInterface
    public boolean deleteRecentNumber(String number) {
        if (!has(Manifest.permission.WRITE_CALL_LOG) || number == null || number.isEmpty()) return false;
        try {
            String d = number.replaceAll("\\D", "");
            int deleted = act.getContentResolver().delete(
                    CallLog.Calls.CONTENT_URI,
                    CallLog.Calls.NUMBER + "=?",
                    new String[]{number});
            if (deleted == 0 && d.length() >= 7) {
                deleted = act.getContentResolver().delete(
                        CallLog.Calls.CONTENT_URI,
                        CallLog.Calls.NUMBER + " LIKE ?",
                        new String[]{"%" + d.substring(d.length() - 7)});
            }
            return deleted > 0;
        } catch (Exception e) {
            return false;
        }
    }

    /* ------------------------------------------------------------------ */
    /* Calling screen API ("Phone")                                        */
    /* ------------------------------------------------------------------ */

    @JavascriptInterface
    public String state() {
        return CallManager.json();
    }

    @JavascriptInterface
    public boolean isDemo() {
        return act.getIntent() != null && act.getIntent().getBooleanExtra("demo", false);
    }

    @JavascriptInterface
    public String demoMode() {
        String m = act.getIntent() == null ? null : act.getIntent().getStringExtra("mode");
        return m == null ? "incoming" : m;
    }

    @JavascriptInterface
    public void answer() {
        ui(new Runnable() {
            @Override
            public void run() {
                CallManager.answer();
            }
        });
    }

    @JavascriptInterface
    public void reject() {
        ui(new Runnable() {
            @Override
            public void run() {
                CallManager.rejectRinging();
            }
        });
    }

    @JavascriptInterface
    public void hangup() {
        ui(new Runnable() {
            @Override
            public void run() {
                CallManager.hangup();
            }
        });
    }

    @JavascriptInterface
    public void mute(final boolean on) {
        ui(new Runnable() {
            @Override
            public void run() {
                CallManager.setMute(on);
            }
        });
    }

    @JavascriptInterface
    public void speaker(final boolean on) {
        ui(new Runnable() {
            @Override
            public void run() {
                CallManager.setSpeaker(on);
            }
        });
    }

    /* ------------------------------------------------------------------ */
    /* Recordings list / fixed audio playback                              */
    /* ------------------------------------------------------------------ */

    private void js(final String code) {
        final WebView w = web;
        if (w == null) return;
        w.post(new Runnable() {
            @Override
            public void run() {
                w.evaluateJavascript(code, null);
            }
        });
    }

    /** Matches the status/navigation bar to the Cream (light) or Night (dark) look. */
    @JavascriptInterface
    public void setLook(final boolean dark) {
        ui(new Runnable() {
            @Override
            public void run() {
                try {
                    Window w = act.getWindow();
                    int c = dark ? 0xFF0A0612 : 0xFFFFF6EE;
                    w.setStatusBarColor(c);
                    w.setNavigationBarColor(c);
                    View d = w.getDecorView();
                    int f = d.getSystemUiVisibility();
                    int light = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
                    d.setSystemUiVisibility(dark ? (f & ~light) : (f | light));
                } catch (Exception ignored) {
                }
            }
        });
    }

    /** Text currently on the clipboard ("" when empty). Only called when the person taps Paste. */
    @JavascriptInterface
    public String pasteText() {
        try {
            ClipboardManager cm = (ClipboardManager) act.getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm == null || !cm.hasPrimaryClip()) return "";
            ClipData cd = cm.getPrimaryClip();
            if (cd == null || cd.getItemCount() == 0) return "";
            CharSequence t = cd.getItemAt(0).coerceToText(act);
            return t == null ? "" : t.toString();
        } catch (Exception e) {
            return "";
        }
    }

    @JavascriptInterface
    public void copyText(final String text) {
        try {
            ClipboardManager cm = (ClipboardManager) act.getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("number", text == null ? "" : text));
        } catch (Exception ignored) {
        }
    }

    @JavascriptInterface
    public void hold(final boolean on) {
        ui(new Runnable() {
            @Override
            public void run() {
                CallManager.hold(on);
            }
        });
    }

    @JavascriptInterface
    public void dtmf(final String s) {
        if (s == null || s.isEmpty()) return;
        ui(new Runnable() {
            @Override
            public void run() {
                CallManager.dtmf(s.charAt(0));
            }
        });
    }

    @JavascriptInterface
    public void close() {
        ui(new Runnable() {
            @Override
            public void run() {
                act.finish();
            }
        });
    }
}
