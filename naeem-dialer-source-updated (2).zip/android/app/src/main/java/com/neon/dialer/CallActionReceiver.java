package com.neon.dialer;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Handles Answer / Decline / Hang up buttons shown on call notifications. */
public class CallActionReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        String a = i.getAction();
        if (a == null) return;
        switch (a) {
            case "ANSWER":
                CallManager.answer();
                Intent o = new Intent(c, InCallActivity.class);
                o.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                try {
                    c.startActivity(o);
                } catch (Exception ignored) {
                }
                break;
            case "DECLINE":
                CallManager.rejectRinging();
                break;
            case "HANGUP":
                CallManager.hangup();
                break;
            default:
                break;
        }
    }
}
