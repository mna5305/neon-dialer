package com.neon.dialer;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.KeyguardManager;
import android.app.Person;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.graphics.drawable.Icon;
import android.telecom.Call;
import android.telecom.CallAudioState;
import android.telecom.InCallService;

/** Bound by the system when this app is the default phone app. Receives every call. */
public class CallService extends InCallService {

    private static final String CH_IN = "neon_incoming";
    private static final String CH_ON = "neon_ongoing";
    private static final int ID_IN = 101;
    private static final int ID_ON = 102;

    private boolean incomingShown = false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable apply = new Runnable() {
        @Override
        public void run() {
            refreshNotifications();
        }
    };

    private final CallManager.Listener listener = new CallManager.Listener() {
        @Override
        public void onChanged() {
            // Small delay so the call screen has time to open first. Otherwise a pop-up would flash
            // on top of it. A locked or sleeping phone shows the call screen full-screen at once.
            handler.removeCallbacks(apply);
            handler.postDelayed(apply, delayFor());
        }
    };

    private long delayFor() {
        if (CallManager.uiVisible) return 0;
        try {
            KeyguardManager km = getSystemService(KeyguardManager.class);
            PowerManager pm = getSystemService(PowerManager.class);
            if ((km != null && km.isKeyguardLocked()) || (pm != null && !pm.isInteractive())) return 0;
        } catch (Exception ignored) {
        }
        return 650;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        CallManager.service = this;
        CallManager.appContext = getApplicationContext();
        createChannels();
        CallManager.addListener(listener);
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        CallManager.removeListener(listener);
        if (CallManager.service == this) CallManager.service = null;
        super.onDestroy();
    }

    @Override
    public void onCallAdded(Call call) {
        super.onCallAdded(call);
        CallManager.add(call);
        launchUi();
    }

    @Override
    public void onCallRemoved(Call call) {
        super.onCallRemoved(call);
        CallManager.remove(call);
    }

    @Override
    public void onCallAudioStateChanged(CallAudioState state) {
        super.onCallAudioStateChanged(state);
        CallManager.muted = state.isMuted();
        CallManager.route = state.getRoute();
        CallManager.fire();
    }

    private void launchUi() {
        Intent i = new Intent(this, InCallActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        try {
            startActivity(i);
        } catch (Exception ignored) {
        }
    }

    private void createChannels() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        NotificationChannel in = new NotificationChannel(CH_IN, "Incoming calls", NotificationManager.IMPORTANCE_HIGH);
        in.setSound(null, null);
        in.enableVibration(false);
        in.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        nm.createNotificationChannel(in);
        NotificationChannel on = new NotificationChannel(CH_ON, "Ongoing call", NotificationManager.IMPORTANCE_LOW);
        on.setSound(null, null);
        nm.createNotificationChannel(on);
    }

    private PendingIntent open(int req) {
        Intent i = new Intent(this, InCallActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return PendingIntent.getActivity(this, req, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private PendingIntent action(String name, int req) {
        Intent i = new Intent(this, CallActionReceiver.class);
        i.setAction(name);
        return PendingIntent.getBroadcast(this, req, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private void refreshNotifications() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        Call ring = CallManager.ringing();
        if (ring != null) {
            nm.cancel(ID_ON);
            if (CallManager.uiVisible) {
                // The person is already looking at the call screen: no pop-up on top of it.
                if (incomingShown) nm.cancel(ID_IN);
                incomingShown = false;
                return;
            }
            if (!incomingShown) {
                incomingShown = true;
                showIncoming(nm, ring);
            }
            return;
        }
        incomingShown = false;
        nm.cancel(ID_IN);
        Call p = CallManager.primary();
        if (p != null && p.getState() != Call.STATE_DISCONNECTED && p.getState() != Call.STATE_DISCONNECTING) {
            showOngoing(nm, p);
        } else {
            nm.cancel(ID_ON);
        }
    }

    private void showIncoming(NotificationManager nm, Call call) {
        String num = CallManager.number(call);
        String known = CallManager.lookup(num);
        boolean spam = CallManager.isSpam(num);
        String title = !known.isEmpty() ? known : (num == null || num.isEmpty() ? "Unknown number" : num);
        String text = spam ? "⚠ Marked as spam" : (known.isEmpty() ? "Incoming call · Not in contacts" : "Incoming call");
        PendingIntent full = open(1);
        PendingIntent answer = action("ANSWER", 2);
        PendingIntent decline = action("DECLINE", 3);

        Notification.Builder b = new Notification.Builder(this, CH_IN)
                .setSmallIcon(android.R.drawable.sym_call_incoming)
                .setContentTitle(title)
                .setContentText(text)
                .setCategory(Notification.CATEGORY_CALL)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setFullScreenIntent(full, true)
                .setContentIntent(full);
        if (Build.VERSION.SDK_INT >= 31) {
            Person caller = new Person.Builder().setName(title).setImportant(true).build();
            b.setStyle(Notification.CallStyle.forIncomingCall(caller, decline, answer));
        } else {
            b.addAction(new Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Decline", decline).build());
            b.addAction(new Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.sym_action_call), "Answer", answer).build());
        }
        nm.cancel(ID_IN); // re-post so the heads-up banner shows again after the call screen was left
        nm.notify(ID_IN, b.build());
    }

    private void showOngoing(NotificationManager nm, Call call) {
        String num = CallManager.number(call);
        String name = CallManager.lookup(num);
        boolean active = call.getState() == Call.STATE_ACTIVE;
        Notification.Builder b = new Notification.Builder(this, CH_ON)
                .setSmallIcon(android.R.drawable.sym_action_call)
                .setContentTitle(name.isEmpty() ? num : name)
                .setContentText(active ? "Ongoing call" : "Calling…")
                .setCategory(Notification.CATEGORY_CALL)
                .setOngoing(true)
                .setContentIntent(open(4))
                .addAction(new Notification.Action.Builder(
                        Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                        "Hang up", action("HANGUP", 5)).build());
        if (active) {
            long t = call.getDetails().getConnectTimeMillis();
            if (t > 0) {
                b.setWhen(t);
                b.setUsesChronometer(true);
            }
        }
        nm.notify(ID_ON, b.build());
    }
}
