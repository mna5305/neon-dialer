package com.neon.dialer;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.ContactsContract;
import android.telecom.Call;
import android.telecom.CallAudioState;
import android.telecom.VideoProfile;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Holds the live calls and exposes simple actions + a JSON snapshot for the HTML call screen. */
public final class CallManager {
    public interface Listener {
        void onChanged();
    }

    private static final List<Call> calls = new ArrayList<>();
    private static final Set<Call> incomingSet = new HashSet<>();
    private static final List<Listener> listeners = new ArrayList<>();
    private static final Handler HANDLER = new Handler(Looper.getMainLooper());

    public static CallService service;
    public static Context appContext;
    public static boolean muted = false;
    public static int route = CallAudioState.ROUTE_EARPIECE;

    private static final Call.Callback CB = new Call.Callback() {
        @Override
        public void onStateChanged(Call call, int state) {
            if (state == Call.STATE_ACTIVE && !CallRecorder.isRecording() && appContext != null
                    && "1".equals(appContext.getSharedPreferences("neon", Context.MODE_PRIVATE).getString("autoRec", "0"))) {
                record(true);
            }
            fire();
        }

        @Override
        public void onDetailsChanged(Call call, Call.Details details) {
            fire();
        }
    };

    private CallManager() {
    }

    public static void addListener(Listener l) {
        if (!listeners.contains(l)) listeners.add(l);
    }

    public static void removeListener(Listener l) {
        listeners.remove(l);
    }

    public static void fire() {
        List<Listener> copy = new ArrayList<>(listeners);
        for (Listener l : copy) {
            try {
                l.onChanged();
            } catch (Exception ignored) {
            }
        }
    }

    public static void add(Call c) {
        if (calls.contains(c)) return;
        if (c.getState() == Call.STATE_RINGING) incomingSet.add(c);
        calls.add(c);
        c.registerCallback(CB);
        fire();
    }

    public static void remove(Call c) {
        c.unregisterCallback(CB);
        calls.remove(c);
        incomingSet.remove(c);
        if (calls.isEmpty()) CallRecorder.stop(appContext);
        fire();
    }

    public static int count() {
        return calls.size();
    }

    public static Call ringing() {
        for (Call c : calls) {
            if (c.getState() == Call.STATE_RINGING) return c;
        }
        return null;
    }

    public static Call primary() {
        Call ring = null;
        Call act = null;
        Call any = null;
        for (Call c : calls) {
            int s = c.getState();
            if (s == Call.STATE_RINGING) {
                if (ring == null) ring = c;
            } else if (s == Call.STATE_ACTIVE || s == Call.STATE_DIALING || s == Call.STATE_CONNECTING) {
                if (act == null) act = c;
            } else if (any == null) {
                any = c;
            }
        }
        if (act != null) return act;
        if (ring != null) return ring;
        return any;
    }

    public static boolean speakerOn() {
        return route == CallAudioState.ROUTE_SPEAKER;
    }

    public static boolean onEarpiece() {
        return route == CallAudioState.ROUTE_EARPIECE;
    }

    public static String number(Call c) {
        try {
            Uri h = c.getDetails().getHandle();
            return h == null ? "" : Uri.decode(h.getSchemeSpecificPart());
        } catch (Exception e) {
            return "";
        }
    }

    public static String lookup(String number) {
        if (number == null || number.isEmpty() || appContext == null) return "";
        try {
            Uri u = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(number));
            Cursor cur = appContext.getContentResolver().query(u,
                    new String[]{ContactsContract.PhoneLookup.DISPLAY_NAME}, null, null, null);
            if (cur != null) {
                try {
                    if (cur.moveToFirst()) {
                        String n = cur.getString(0);
                        return n == null ? "" : n;
                    }
                } finally {
                    cur.close();
                }
            }
        } catch (Exception ignored) {
        }
        return "";
    }

    private static String stateName(Call c) {
        switch (c.getState()) {
            case Call.STATE_RINGING:
                return "ringing";
            case Call.STATE_DIALING:
            case Call.STATE_CONNECTING:
                return "dialing";
            case Call.STATE_ACTIVE:
                return "active";
            case Call.STATE_HOLDING:
                return "holding";
            case Call.STATE_DISCONNECTING:
            case Call.STATE_DISCONNECTED:
                return "ended";
            default:
                return "dialing";
        }
    }

    public static String json() {
        try {
            JSONObject o = new JSONObject();
            o.put("now", System.currentTimeMillis());
            Call p = primary();
            if (p == null) {
                o.put("state", "none");
                return o.toString();
            }
            String num = number(p);
            String nm = lookup(num);
            if (nm.isEmpty()) {
                CharSequence cd = p.getDetails().getCallerDisplayName();
                if (cd != null) nm = cd.toString();
            }
            o.put("state", stateName(p));
            o.put("number", num);
            o.put("name", nm);
            o.put("incoming", incomingSet.contains(p));
            o.put("connectTime", p.getDetails().getConnectTimeMillis());
            o.put("muted", muted);
            o.put("speaker", speakerOn());
            o.put("holding", p.getState() == Call.STATE_HOLDING);
            o.put("count", calls.size());
            o.put("recording", CallRecorder.isRecording());
            o.put("recStart", CallRecorder.startedAt());
            o.put("recError", CallRecorder.lastError());
            o.put("recSource", CallRecorder.activeSource());
            o.put("recLevel", CallRecorder.isRecording() ? Math.min(100, CallRecorder.maxAmplitude() / 220) : 0);

            Call w = ringing();
            if (w != null && w != p) {
                JSONObject wj = new JSONObject();
                String wn = number(w);
                wj.put("number", wn);
                wj.put("name", lookup(wn));
                o.put("waiting", wj);
            }
            return o.toString();
        } catch (Exception e) {
            return "{\"state\":\"none\"}";
        }
    }

    public static void record(boolean on) {
        if (appContext == null) return;
        if (on) {
            Call p = primary();
            String n = p == null ? "" : number(p);
            String nm = lookup(n);
            CallRecorder.start(appContext, nm.isEmpty() ? n : nm);
        } else {
            CallRecorder.stop(appContext);
        }
        fire();
    }

    public static void answer() {
        Call c = ringing();
        if (c != null) c.answer(VideoProfile.STATE_AUDIO_ONLY);
    }

    public static void rejectRinging() {
        Call c = ringing();
        if (c != null) c.reject(false, null);
    }

    public static void hangup() {
        Call p = primary();
        if (p == null) return;
        if (p.getState() == Call.STATE_RINGING) p.reject(false, null);
        else p.disconnect();
    }

    public static void setMute(boolean m) {
        if (service != null) service.setMuted(m);
        muted = m;
        fire();
    }

    public static void setSpeaker(boolean on) {
        if (service != null) {
            service.setAudioRoute(on ? CallAudioState.ROUTE_SPEAKER : CallAudioState.ROUTE_WIRED_OR_EARPIECE);
        }
    }

    public static void hold(boolean h) {
        Call p = primary();
        if (p == null) return;
        if (h) p.hold();
        else p.unhold();
    }

    public static void dtmf(char ch) {
        final Call p = primary();
        if (p == null) return;
        p.playDtmfTone(ch);
        HANDLER.postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    p.stopDtmfTone();
                } catch (Exception ignored) {
                }
            }
        }, 160);
    }
}
