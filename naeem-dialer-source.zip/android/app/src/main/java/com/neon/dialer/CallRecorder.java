package com.neon.dialer;

import android.Manifest;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.media.MediaRecorder;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Reliable call & audio recorder for Android 8-14.
 * Records to a real seekable local .m4a file first (ensuring a valid MP4/AAC header),
 * waits for RecordService microphone foreground state, monitors live amplitude for
 * zero-frame silence fallback, and exports cleanly to Music/CallRecordings on stop.
 */
public final class CallRecorder {
    private static final Handler HANDLER = new Handler(Looper.getMainLooper());
    private static MediaRecorder rec;
    private static File outFile;
    private static String fileName = "";
    private static long startedAt = 0;
    private static String lastError = "";
    private static String activeSourceName = "";
    private static int peakAmp = 0;
    private static volatile boolean starting = false;

    private CallRecorder() {
    }

    public static synchronized boolean isRecording() {
        return rec != null || starting;
    }

    public static synchronized long startedAt() {
        return startedAt;
    }

    public static synchronized String lastError() {
        return lastError;
    }

    public static synchronized String activeSource() {
        return activeSourceName;
    }

    public static synchronized int maxAmplitude() {
        if (rec == null) return 0;
        try {
            int a = rec.getMaxAmplitude();
            if (a > peakAmp) peakAmp = a;
            return a;
        } catch (Exception e) {
            return 0;
        }
    }

    public static boolean start(final Context ctx, final String label) {
        synchronized (CallRecorder.class) {
            if (rec != null || starting) return true;
            lastError = "";
            activeSourceName = "";
            peakAmp = 0;
            if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                lastError = "Microphone permission needed";
                return false;
            }
            starting = true;
        }

        // Start microphone foreground service FIRST
        RecordService.begin(ctx);

        SharedPreferences prefs = ctx.getSharedPreferences("neon", Context.MODE_PRIVATE);
        final String prefSrc = prefs.getString("recSource", "auto");
        final boolean autoSpeaker = "1".equals(prefs.getString("autoSpeakerRec", "0"));

        if (autoSpeaker && !CallManager.speakerOn() && CallManager.count() > 0) {
            try {
                CallManager.setSpeaker(true);
            } catch (Exception ignored) {
            }
        }

        new Thread(new Runnable() {
            @Override
            public void run() {
                // Wait briefly for RecordService.startForeground(MICROPHONE) to become active
                for (int i = 0; i < 12 && !RecordService.ready; i++) {
                    try {
                        Thread.sleep(40);
                    } catch (InterruptedException ignored) {
                    }
                }
                startInternal(ctx.getApplicationContext(), label, prefSrc, 0);
            }
        }).start();

        return true;
    }

    private static int[] sourcesFor(String prefSrc) {
        if ("voice_call".equals(prefSrc)) {
            return new int[]{
                    MediaRecorder.AudioSource.VOICE_CALL,
                    MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                    MediaRecorder.AudioSource.MIC
            };
        } else if ("voice_comm".equals(prefSrc)) {
            return new int[]{
                    MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                    MediaRecorder.AudioSource.MIC,
                    MediaRecorder.AudioSource.VOICE_RECOGNITION
            };
        } else if ("mic".equals(prefSrc)) {
            return new int[]{
                    MediaRecorder.AudioSource.MIC,
                    MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                    MediaRecorder.AudioSource.VOICE_RECOGNITION
            };
        }
        // "auto": Try MIC first (best with speaker/ambient), then VOICE_COMMUNICATION, then VOICE_RECOGNITION
        return new int[]{
                MediaRecorder.AudioSource.MIC,
                MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                MediaRecorder.AudioSource.VOICE_RECOGNITION
        };
    }

    private static synchronized void startInternal(final Context ctx, final String label, final String prefSrc, final int startIdx) {
        if (!starting && rec == null) return;

        try {
            AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            if (am != null && am.isMicrophoneMute() && !CallManager.muted) {
                am.setMicrophoneMute(false);
            }
        } catch (Exception ignored) {
        }

        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        String safe = label == null ? "" : label.replaceAll("[^A-Za-z0-9+ _-]", "").trim();
        if (safe.isEmpty()) safe = "Call";
        fileName = "Call_" + safe.replace(' ', '_') + "_" + stamp + ".m4a";

        File dir = new File(ctx.getExternalFilesDir(null), "CallRecordings");
        if (!dir.exists()) dir.mkdirs();

        final int[] sources = sourcesFor(prefSrc);
        for (int idx = startIdx; idx < sources.length; idx++) {
            final int src = sources[idx];
            final int nextIdx = idx + 1;
            MediaRecorder r = null;
            File f = new File(dir, fileName);
            try {
                if (f.exists()) f.delete();
                r = Build.VERSION.SDK_INT >= 31 ? new MediaRecorder(ctx) : new MediaRecorder();
                r.setAudioSource(src);
                r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
                r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
                r.setAudioChannels(1);
                r.setAudioEncodingBitRate(128000);
                r.setAudioSamplingRate(44100);
                r.setOutputFile(f.getAbsolutePath());
                r.prepare();
                r.start();
                try {
                    r.getMaxAmplitude(); // prime amplitude meter
                } catch (Exception ignored) {
                }
                rec = r;
                outFile = f;
                startedAt = System.currentTimeMillis();
                activeSourceName = sourceName(src);
                starting = false;
                peakAmp = 0;

                // Watchdog: if source yields 0 amplitude after 1.6s (OEM HAL silenced it), fall back to next source
                if (nextIdx < sources.length) {
                    final MediaRecorder activeRec = r;
                    HANDLER.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            checkSilenceAndFallback(ctx, label, prefSrc, activeRec, nextIdx);
                        }
                    }, 1600);
                }
                CallManager.fire();
                return;
            } catch (Exception e) {
                lastError = String.valueOf(e.getMessage());
                try {
                    if (r != null) r.release();
                } catch (Exception ignored) {
                }
                if (f.exists()) f.delete();
            }
        }
        starting = false;
        RecordService.end(ctx);
        CallManager.fire();
    }

    private static synchronized void checkSilenceAndFallback(Context ctx, String label, String prefSrc, MediaRecorder watched, int nextIdx) {
        if (rec == null || rec != watched) return;
        int amp = maxAmplitude();
        if (amp == 0 && peakAmp == 0) {
            // Current source produced pure digital silence; switch to next audio source
            try {
                rec.stop();
            } catch (Exception ignored) {
            }
            try {
                rec.reset();
                rec.release();
            } catch (Exception ignored) {
            }
            rec = null;
            if (outFile != null && outFile.exists()) outFile.delete();
            outFile = null;
            starting = true;
            startInternal(ctx, label, prefSrc, nextIdx);
        }
    }

    private static String sourceName(int src) {
        if (src == MediaRecorder.AudioSource.VOICE_CALL) return "Voice Line";
        if (src == MediaRecorder.AudioSource.VOICE_COMMUNICATION) return "Voice Comm";
        if (src == MediaRecorder.AudioSource.VOICE_RECOGNITION) return "Mic HD";
        return "Microphone";
    }

    public static synchronized void stop(Context ctx) {
        starting = false;
        HANDLER.removeCallbacksAndMessages(null);
        if (rec == null) {
            if (ctx != null) RecordService.end(ctx);
            return;
        }
        try {
            rec.stop();
        } catch (Exception ignored) {
        }
        try {
            rec.reset();
        } catch (Exception ignored) {
        }
        try {
            rec.release();
        } catch (Exception ignored) {
        }
        rec = null;

        // Export finalized valid .m4a file to Music/CallRecordings on Android 10+
        final File finalized = outFile;
        final String nameCopy = fileName;
        outFile = null;
        fileName = "";
        startedAt = 0;
        activeSourceName = "";

        if (finalized != null && finalized.exists() && finalized.length() > 512 && ctx != null) {
            if (Build.VERSION.SDK_INT >= 29) {
                exportToMediaStore(ctx.getApplicationContext(), finalized, nameCopy);
            } else {
                try {
                    MediaScannerConnection.scanFile(ctx, new String[]{finalized.getAbsolutePath()}, new String[]{"audio/mp4"}, null);
                } catch (Exception ignored) {
                }
            }
        }
        if (ctx != null) RecordService.end(ctx);
    }

    private static void exportToMediaStore(Context ctx, File srcFile, String fname) {
        Uri uri = null;
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Audio.Media.DISPLAY_NAME, fname);
            v.put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4");
            v.put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/CallRecordings");
            v.put(MediaStore.Audio.Media.IS_PENDING, 1);
            uri = ctx.getContentResolver().insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, v);
            if (uri == null) return;
            try (FileInputStream in = new FileInputStream(srcFile);
                 OutputStream out = ctx.getContentResolver().openOutputStream(uri)) {
                if (out == null) throw new Exception("No output stream");
                byte[] buf = new byte[16384];
                int len;
                while ((len = in.read(buf)) > 0) {
                    out.write(buf, 0, len);
                }
                out.flush();
            }
            ContentValues done = new ContentValues();
            done.put(MediaStore.Audio.Media.IS_PENDING, 0);
            ctx.getContentResolver().update(uri, done, null, null);
            // Keep app-private copy? Remove duplicate so list doesn't show twice
            srcFile.delete();
        } catch (Exception e) {
            // Keep srcFile in app-private CallRecordings as fallback so user never loses recording!
            if (uri != null) {
                try {
                    ctx.getContentResolver().delete(uri, null, null);
                } catch (Exception ignored) {
                }
            }
        }
    }
}
