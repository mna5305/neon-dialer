package com.neon.dialer;

import android.Manifest;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.AudioManager;
import android.media.MediaRecorder;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Reliable call recorder for Android 8-14.
 * Fixes silent recordings caused by VOICE_CALL returning 0-amplitude frames on Android 10+
 * and ensures foreground microphone service starts before MediaRecorder capture.
 */
public final class CallRecorder {
    private static MediaRecorder rec;
    private static ParcelFileDescriptor pfd;
    private static Uri outUri;
    private static File outFile;
    private static long startedAt = 0;
    private static String lastError = "";
    private static String activeSourceName = "";

    private CallRecorder() {
    }

    public static synchronized boolean isRecording() {
        return rec != null;
    }

    public static synchronized long startedAt() {
        return startedAt;
    }

    public static synchronized String lastError() {
        return lastError;
    }

    public static synchronized String activeSource() {
        return activeSourceName;
    }

    public static synchronized int maxAmplitude() {
        if (rec == null) return 0;
        try {
            return rec.getMaxAmplitude();
        } catch (Exception e) {
            return 0;
        }
    }

    public static synchronized boolean start(Context ctx, String label) {
        if (rec != null) return true;
        lastError = "";
        activeSourceName = "";
        if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            lastError = "Microphone permission needed";
            return false;
        }

        SharedPreferences prefs = ctx.getSharedPreferences("neon", Context.MODE_PRIVATE);
        String prefSrc = prefs.getString("recSource", "auto");
        boolean autoSpeaker = "1".equals(prefs.getString("autoSpeakerRec", "0"));

        // Start microphone foreground service BEFORE preparing/starting MediaRecorder
        RecordService.begin(ctx);

        // Optional: automatically turn speaker on when recording so both voices capture clearly
        if (autoSpeaker && !CallManager.speakerOn()) {
            try {
                CallManager.setSpeaker(true);
            } catch (Exception ignored) {
            }
        }

        // Ensure mic is not muted at AudioManager level
        try {
            AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            if (am != null && am.isMicrophoneMute() && !CallManager.muted) {
                am.setMicrophoneMute(false);
            }
        } catch (Exception ignored) {
        }

        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        String safe = label == null ? "" : label.replaceAll("[^A-Za-z0-9+ _-]", "").trim();
        if (safe.isEmpty()) safe = "Call";
        String fname = "Call_" + safe.replace(' ', '_') + "_" + stamp + ".m4a";

        int[] sources;
        if ("voice_call".equals(prefSrc)) {
            sources = new int[]{
                    MediaRecorder.AudioSource.VOICE_CALL,
                    MediaRecorder.AudioSource.VOICE_RECOGNITION,
                    MediaRecorder.AudioSource.MIC
            };
        } else if ("voice_comm".equals(prefSrc)) {
            sources = new int[]{
                    MediaRecorder.AudioSource.VOICE_COMMUNICATION,
                    MediaRecorder.AudioSource.VOICE_RECOGNITION,
                    MediaRecorder.AudioSource.MIC
            };
        } else if ("mic".equals(prefSrc)) {
            sources = new int[]{
                    MediaRecorder.AudioSource.MIC,
                    MediaRecorder.AudioSource.VOICE_RECOGNITION
            };
        } else {
            // "auto" (Default): Avoid VOICE_CALL because on Android 10+ it frequently succeeds
            // start() while writing all-zero silent frames. VOICE_RECOGNITION & MIC capture
            // clean, un-suppressed audio without aggressive AEC cancelling the remote caller.
            sources = new int[]{
                    MediaRecorder.AudioSource.VOICE_RECOGNITION,
                    MediaRecorder.AudioSource.MIC,
                    MediaRecorder.AudioSource.VOICE_COMMUNICATION
            };
        }

        for (int src : sources) {
            MediaRecorder r = null;
            try {
                openOutput(ctx, fname);
                r = Build.VERSION.SDK_INT >= 31 ? new MediaRecorder(ctx) : new MediaRecorder();
                r.setAudioSource(src);
                r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
                r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
                r.setAudioChannels(1);
                r.setAudioEncodingBitRate(128000);
                r.setAudioSamplingRate(44100);
                if (pfd != null) r.setOutputFile(pfd.getFileDescriptor());
                else r.setOutputFile(outFile.getAbsolutePath());
                r.prepare();
                r.start();
                try {
                    r.getMaxAmplitude(); // prime amplitude meter
                } catch (Exception ignored) {
                }
                rec = r;
                startedAt = System.currentTimeMillis();
                activeSourceName = sourceName(src);
                return true;
            } catch (Exception e) {
                lastError = String.valueOf(e.getMessage());
                try {
                    if (r != null) r.release();
                } catch (Exception ignored) {
                }
                cleanupFailed(ctx);
            }
        }
        RecordService.end(ctx);
        return false;
    }

    private static String sourceName(int src) {
        if (src == MediaRecorder.AudioSource.VOICE_CALL) return "Voice Line";
        if (src == MediaRecorder.AudioSource.VOICE_COMMUNICATION) return "Voice Comm";
        if (src == MediaRecorder.AudioSource.VOICE_RECOGNITION) return "Mic HD";
        return "Microphone";
    }

    private static void openOutput(Context ctx, String fname) throws Exception {
        pfd = null;
        outUri = null;
        outFile = null;
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Audio.Media.DISPLAY_NAME, fname);
            v.put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4");
            v.put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/CallRecordings");
            v.put(MediaStore.Audio.Media.IS_PENDING, 1);
            outUri = ctx.getContentResolver().insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, v);
            if (outUri == null) throw new Exception("Could not create the file");
            pfd = ctx.getContentResolver().openFileDescriptor(outUri, "rw");
            if (pfd == null) {
                pfd = ctx.getContentResolver().openFileDescriptor(outUri, "w");
            }
            if (pfd == null) throw new Exception("Could not open recording file descriptor");
        } else {
            File dir = new File(ctx.getExternalFilesDir(null), "CallRecordings");
            if (!dir.exists()) dir.mkdirs();
            outFile = new File(dir, fname);
        }
    }

    private static void cleanupFailed(Context ctx) {
        try {
            if (pfd != null) pfd.close();
        } catch (Exception ignored) {
        }
        pfd = null;
        try {
            if (outUri != null) ctx.getContentResolver().delete(outUri, null, null);
        } catch (Exception ignored) {
        }
        try {
            if (outFile != null) outFile.delete();
        } catch (Exception ignored) {
        }
        outUri = null;
        outFile = null;
    }

    public static synchronized void stop(Context ctx) {
        if (rec == null) return;
        try {
            rec.stop();
        } catch (Exception ignored) {
        }
        try {
            rec.reset();
        } catch (Exception ignored) {
        }
        try {
            rec.release();
        } catch (Exception ignored) {
        }
        rec = null;
        try {
            if (pfd != null) {
                try {
                    pfd.getFileDescriptor().sync();
                } catch (Exception ignored) {
                }
                pfd.close();
            }
        } catch (Exception ignored) {
        }
        pfd = null;

        if (Build.VERSION.SDK_INT >= 29 && outUri != null && ctx != null) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Audio.Media.IS_PENDING, 0);
            try {
                ctx.getContentResolver().update(outUri, v, null, null);
            } catch (Exception ignored) {
            }
        } else if (outFile != null && outFile.exists() && ctx != null) {
            try {
                MediaScannerConnection.scanFile(ctx, new String[]{outFile.getAbsolutePath()}, new String[]{"audio/mp4"}, null);
            } catch (Exception ignored) {
            }
        }

        outUri = null;
        outFile = null;
        startedAt = 0;
        activeSourceName = "";
        if (ctx != null) RecordService.end(ctx);
    }
}
