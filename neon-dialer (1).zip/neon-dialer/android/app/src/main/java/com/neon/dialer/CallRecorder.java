package com.neon.dialer;

import android.Manifest;
import android.content.ContentValues;
import android.content.Context;
import android.content.pm.PackageManager;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Records the call with MediaRecorder. Android does not let normal apps capture the other
 * person's voice directly, so this uses the microphone (works best on speaker).
 * Files are saved to Music/CallRecordings.
 */
public final class CallRecorder {

    private static MediaRecorder rec;
    private static Uri outUri;
    private static File outFile;
    private static ParcelFileDescriptor pfd;
    private static long startedAt = 0;
    private static String lastError = "";

    private CallRecorder() {
    }

    public static synchronized boolean isRecording() {
        return rec != null;
    }

    public static synchronized long startedAt() {
        return startedAt;
    }

    public static synchronized String lastError() {
        return lastError;
    }

    public static synchronized boolean start(Context ctx, String label) {
        if (rec != null) return true;
        lastError = "";
        if (ctx.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            lastError = "Microphone permission needed";
            return false;
        }
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        String safe = label == null ? "" : label.replaceAll("[^A-Za-z0-9+ _-]", "").trim();
        if (safe.isEmpty()) safe = "Call";
        String fname = "Call_" + safe.replace(' ', '_') + "_" + stamp + ".m4a";

        // First try the call audio source (works on some phones), then the microphone.
        int[] sources = {MediaRecorder.AudioSource.VOICE_CALL, MediaRecorder.AudioSource.MIC};
        for (int src : sources) {
            MediaRecorder r = null;
            try {
                openOutput(ctx, fname);
                r = Build.VERSION.SDK_INT >= 31 ? new MediaRecorder(ctx) : new MediaRecorder();
                r.setAudioSource(src);
                r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
                r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
                r.setAudioEncodingBitRate(96000);
                r.setAudioSamplingRate(44100);
                if (pfd != null) r.setOutputFile(pfd.getFileDescriptor());
                else r.setOutputFile(outFile.getAbsolutePath());
                r.prepare();
                r.start();
                rec = r;
                startedAt = System.currentTimeMillis();
                RecordService.begin(ctx);
                return true;
            } catch (Exception e) {
                lastError = String.valueOf(e.getMessage());
                try {
                    if (r != null) r.release();
                } catch (Exception ignored) {
                }
                cleanupFailed(ctx);
            }
        }
        return false;
    }

    private static void openOutput(Context ctx, String fname) throws Exception {
        pfd = null;
        outUri = null;
        outFile = null;
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Audio.Media.DISPLAY_NAME, fname);
            v.put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4");
            v.put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/CallRecordings");
            v.put(MediaStore.Audio.Media.IS_PENDING, 1);
            outUri = ctx.getContentResolver().insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, v);
            if (outUri == null) throw new Exception("Could not create the file");
            pfd = ctx.getContentResolver().openFileDescriptor(outUri, "w");
        } else {
            File dir = new File(ctx.getExternalFilesDir(null), "CallRecordings");
            dir.mkdirs();
            outFile = new File(dir, fname);
        }
    }

    private static void cleanupFailed(Context ctx) {
        try {
            if (pfd != null) pfd.close();
        } catch (Exception ignored) {
        }
        pfd = null;
        try {
            if (outUri != null) ctx.getContentResolver().delete(outUri, null, null);
        } catch (Exception ignored) {
        }
        try {
            if (outFile != null) outFile.delete();
        } catch (Exception ignored) {
        }
        outUri = null;
        outFile = null;
    }

    public static synchronized void stop(Context ctx) {
        if (rec == null) return;
        try {
            rec.stop();
        } catch (Exception ignored) {
        }
        try {
            rec.release();
        } catch (Exception ignored) {
        }
        rec = null;
        try {
            if (pfd != null) pfd.close();
        } catch (Exception ignored) {
        }
        pfd = null;
        if (Build.VERSION.SDK_INT >= 29 && outUri != null && ctx != null) {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Audio.Media.IS_PENDING, 0);
            try {
                ctx.getContentResolver().update(outUri, v, null, null);
            } catch (Exception ignored) {
            }
        }
        outUri = null;
        outFile = null;
        startedAt = 0;
        if (ctx != null) RecordService.end(ctx);
    }
}
