package com.neon.dialer;

import android.Manifest;
import android.app.Activity;
import android.app.role.RoleManager;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.media.MediaPlayer;
import android.provider.MediaStore;
import android.webkit.WebView;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.telecom.TelecomManager;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

/** JavaScript <-> Android bridge. Exposed as "Dialer" (main UI) and "Phone" (calling screen). */
public class Bridge {

    private final Activity act;
    public WebView web;
    private static MediaPlayer player;
    private static long playingId = -1;

    public Bridge(Activity a) {
        act = a;
    }

    private void ui(Runnable r) {
        act.runOnUiThread(r);
    }

    private boolean has(String p) {
        return act.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    private SharedPreferences sp() {
        return act.getSharedPreferences("neon", Activity.MODE_PRIVATE);
    }

    /* ------------------------------------------------------------------ */
    /* Preferences (call-screen theme, accent colour, ...)                 */
    /* ------------------------------------------------------------------ */

    @JavascriptInterface
    public String getPref(String k, String d) {
        return sp().getString(k, d);
    }

    @JavascriptInterface
    public void setPref(String k, String v) {
        sp().edit().putString(k, v).apply();
    }

    @JavascriptInterface
    public void toast(final String m) {
        ui(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(act, m, Toast.LENGTH_SHORT).show();
            }
        });
    }

    /* ------------------------------------------------------------------ */
    /* Permissions + default phone app                                     */
    /* ------------------------------------------------------------------ */

    @JavascriptInterface
    public String hasPerms() {
        try {
            JSONObject o = new JSONObject();
            o.put("contacts", has(Manifest.permission.READ_CONTACTS));
            o.put("log", has(Manifest.permission.READ_CALL_LOG));
            o.put("phone", has(Manifest.permission.CALL_PHONE) && has(Manifest.permission.READ_PHONE_STATE));
            o.put("mic", has(Manifest.permission.RECORD_AUDIO));
            o.put("def", isDefault());
            return o.toString();
        } catch (Exception e) {
            return "{}";
        }
    }

    @JavascriptInterface
    public void askPerms() {
        ui(new Runnable() {
            @Override
            public void run() {
                ArrayList<String> l = new ArrayList<>();
                String[] all = {
                        Manifest.permission.READ_CONTACTS,
                        Manifest.permission.READ_CALL_LOG,
                        Manifest.permission.CALL_PHONE,
                        Manifest.permission.READ_PHONE_STATE,
                        Manifest.permission.ANSWER_PHONE_CALLS,
                        Manifest.permission.RECORD_AUDIO
                };
                for (String p : all) {
                    if (!has(p)) l.add(p);
                }
                if (Build.VERSION.SDK_INT >= 33 && !has(Manifest.permission.POST_NOTIFICATIONS)) {
                    l.add(Manifest.permission.POST_NOTIFICATIONS);
                }
                if (!l.isEmpty()) act.requestPermissions(l.toArray(new String[0]), 77);
            }
        });
    }

    @JavascriptInterface
    public boolean isDefault() {
        try {
            TelecomManager tm = act.getSystemService(TelecomManager.class);
            return tm != null && act.getPackageName().equals(tm.getDefaultDialerPackage());
        } catch (Exception e) {
            return false;
        }
    }

    @JavascriptInterface
    public void requestDefault() {
        ui(new Runnable() {
            @Override
            public void run() {
                try {
                    if (Build.VERSION.SDK_INT >= 29) {
                        RoleManager rm = act.getSystemService(RoleManager.class);
                        if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_DIALER)) {
                            act.startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_DIALER), 1001);
                            return;
                        }
                    }
                    Intent i = new Intent(TelecomManager.ACTION_CHANGE_DEFAULT_DIALER);
                    i.putExtra(TelecomManager.EXTRA_CHANGE_DEFAULT_DIALER_PACKAGE_NAME, act.getPackageName());
                    act.startActivityForResult(i, 1001);
                } catch (Exception e) {
                    Toast.makeText(act, "Could not open the default app picker", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    /* ------------------------------------------------------------------ */
    /* Placing calls + opening things                                      */
    /* ------------------------------------------------------------------ */

    @JavascriptInterface
    public void call(final String num) {
        ui(new Runnable() {
            @Override
            public void run() {
                if (!has(Manifest.permission.CALL_PHONE)) {
                    act.requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, 78);
                    return;
                }
                try {
                    TelecomManager tm = act.getSystemService(TelecomManager.class);
                    tm.placeCall(Uri.fromParts("tel", num, null), new Bundle());
                } catch (Exception e) {
                    Toast.makeText(act, "Could not place the call", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    @JavascriptInterface
    public void open(final String url) {
        ui(new Runnable() {
            @Override
            public void run() {
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    act.startActivity(i);
                } catch (Exception e) {
                    Toast.makeText(act, "No app found for this action", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @JavascriptInterface
    public void addContact(final String name, final String num) {
        ui(new Runnable() {
            @Override
            public void run() {
                try {
                    Intent i = new Intent(Intent.ACTION_INSERT, ContactsContract.Contacts.CONTENT_URI);
                    if (name != null && !name.isEmpty()) i.putExtra(ContactsContract.Intents.Insert.NAME, name);
                    if (num != null && !num.isEmpty()) i.putExtra(ContactsContract.Intents.Insert.PHONE, num);
                    act.startActivity(i);
                } catch (Exception e) {
                    Toast.makeText(act, "Contacts app not available", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @JavascriptInterface
    public void openContact(final String id) {
        ui(new Runnable() {
            @Override
            public void run() {
                try {
                    Uri u = Uri.withAppendedPath(ContactsContract.Contacts.CONTENT_URI, id);
                    act.startActivity(new Intent(Intent.ACTION_VIEW, u));
                } catch (Exception e) {
                    Toast.makeText(act, "Could not open contact", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @JavascriptInterface
    public void openDialer() {
        ui(new Runnable() {
            @Override
            public void run() {
                Intent i = new Intent(act, MainActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                act.startActivity(i);
            }
        });
    }

    @JavascriptInterface
    public void previewCall(final String mode) {
        ui(new Runnable() {
            @Override
            public void run() {
                Intent i = new Intent(act, InCallActivity.class);
                i.putExtra("demo", true);
                i.putExtra("mode", mode);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                act.startActivity(i);
            }
        });
    }

    /* ------------------------------------------------------------------ */
    /* Contacts + call log                                                 */
    /* ------------------------------------------------------------------ */

    @JavascriptInterface
    public String getContacts() {
        JSONArray arr = new JSONArray();
        if (!has(Manifest.permission.READ_CONTACTS)) return arr.toString();
        String[] proj = {
                ContactsContract.CommonDataKinds.Phone.CONTACT_ID,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER,
                ContactsContract.Contacts.STARRED
        };
        Cursor c = null;
        try {
            c = act.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, proj, null, null,
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE NOCASE ASC");
            if (c != null) {
                Set<String> seen = new HashSet<>();
                while (c.moveToNext()) {
                    String num = c.getString(2);
                    if (num == null) continue;
                    String key = c.getLong(0) + ":" + num.replaceAll("\\D", "");
                    if (!seen.add(key)) continue;
                    JSONObject o = new JSONObject();
                    o.put("id", c.getLong(0));
                    o.put("name", c.getString(1));
                    o.put("num", num);
                    o.put("star", c.getInt(3) == 1);
                    arr.put(o);
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return arr.toString();
    }

    @JavascriptInterface
    public String getRecents() {
        JSONArray arr = new JSONArray();
        if (!has(Manifest.permission.READ_CALL_LOG)) return arr.toString();
        String[] proj = {
                CallLog.Calls.NUMBER,
                CallLog.Calls.CACHED_NAME,
                CallLog.Calls.TYPE,
                CallLog.Calls.DATE,
                CallLog.Calls.DURATION
        };
        Cursor c = null;
        try {
            Bundle q = new Bundle();
            q.putInt(ContentResolver.QUERY_ARG_LIMIT, 250);
            q.putStringArray(ContentResolver.QUERY_ARG_SORT_COLUMNS, new String[]{CallLog.Calls.DATE});
            q.putInt(ContentResolver.QUERY_ARG_SORT_DIRECTION, ContentResolver.QUERY_SORT_DIRECTION_DESCENDING);
            c = act.getContentResolver().query(CallLog.Calls.CONTENT_URI, proj, q, null);
            if (c != null) {
                while (c.moveToNext()) {
                    JSONObject o = new JSONObject();
                    o.put("number", c.getString(0));
                    o.put("name", c.getString(1) == null ? "" : c.getString(1));
                    o.put("type", c.getInt(2));
                    o.put("date", c.getLong(3));
                    o.put("duration", c.getLong(4));
                    arr.put(o);
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return arr.toString();
    }

    /* ------------------------------------------------------------------ */
    /* Calling screen API ("Phone")                                        */
    /* ------------------------------------------------------------------ */

    @JavascriptInterface
    public String state() {
        return CallManager.json();
    }

    @JavascriptInterface
    public boolean isDemo() {
        return act.getIntent() != null && act.getIntent().getBooleanExtra("demo", false);
    }

    @JavascriptInterface
    public String demoMode() {
        String m = act.getIntent() == null ? null : act.getIntent().getStringExtra("mode");
        return m == null ? "incoming" : m;
    }

    @JavascriptInterface
    public void answer() {
        ui(new Runnable() {
            @Override
            public void run() {
                CallManager.answer();
            }
        });
    }

    @JavascriptInterface
    public void reject() {
        ui(new Runnable() {
            @Override
            public void run() {
                CallManager.rejectRinging();
            }
        });
    }

    @JavascriptInterface
    public void hangup() {
        ui(new Runnable() {
            @Override
            public void run() {
                CallManager.hangup();
            }
        });
    }

    @JavascriptInterface
    public void mute(final boolean on) {
        ui(new Runnable() {
            @Override
            public void run() {
                CallManager.setMute(on);
            }
        });
    }

    @JavascriptInterface
    public void speaker(final boolean on) {
        ui(new Runnable() {
            @Override
            public void run() {
                CallManager.setSpeaker(on);
            }
        });
    }

    @JavascriptInterface
    public void record(final boolean on) {
        ui(new Runnable() {
            @Override
            public void run() {
                if (on && !has(Manifest.permission.RECORD_AUDIO)) {
                    act.requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 79);
                    Toast.makeText(act, "Allow the microphone, then tap Record again", Toast.LENGTH_LONG).show();
                    return;
                }
                CallManager.record(on);
            }
        });
    }

    /* ------------------------------------------------------------------ */
    /* Recordings list / playback                                          */
    /* ------------------------------------------------------------------ */

    private void js(final String code) {
        final WebView w = web;
        if (w == null) return;
        w.post(new Runnable() {
            @Override
            public void run() {
                w.evaluateJavascript(code, null);
            }
        });
    }

    private static void stopPlayer() {
        if (player != null) {
            try {
                player.stop();
            } catch (Exception ignored) {
            }
            try {
                player.release();
            } catch (Exception ignored) {
            }
        }
        player = null;
        playingId = -1;
    }

    @JavascriptInterface
    public String getRecordings() {
        JSONArray arr = new JSONArray();
        if (Build.VERSION.SDK_INT < 29) return arr.toString();
        Cursor c = null;
        try {
            String[] proj = {
                    MediaStore.Audio.Media._ID,
                    MediaStore.Audio.Media.DISPLAY_NAME,
                    MediaStore.Audio.Media.DATE_ADDED,
                    MediaStore.Audio.Media.DURATION,
                    MediaStore.Audio.Media.SIZE
            };
            c = act.getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj,
                    MediaStore.Audio.Media.RELATIVE_PATH + " LIKE ?", new String[]{"Music/CallRecordings%"},
                    MediaStore.Audio.Media.DATE_ADDED + " DESC");
            if (c != null) {
                while (c.moveToNext()) {
                    JSONObject o = new JSONObject();
                    o.put("id", c.getLong(0));
                    o.put("name", c.getString(1));
                    o.put("date", c.getLong(2) * 1000L);
                    o.put("dur", c.getLong(3));
                    o.put("size", c.getLong(4));
                    arr.put(o);
                }
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return arr.toString();
    }

    @JavascriptInterface
    public void playRec(final String id) {
        ui(new Runnable() {
            @Override
            public void run() {
                try {
                    long l = Long.parseLong(id);
                    if (player != null && playingId == l) {
                        stopPlayer();
                        js("window.onPlay&&window.onPlay('')");
                        return;
                    }
                    stopPlayer();
                    Uri u = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, l);
                    MediaPlayer mp = new MediaPlayer();
                    mp.setDataSource(act, u);
                    mp.prepare();
                    mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                        @Override
                        public void onCompletion(MediaPlayer m) {
                            stopPlayer();
                            js("window.onPlay&&window.onPlay('')");
                        }
                    });
                    mp.start();
                    player = mp;
                    playingId = l;
                    js("window.onPlay&&window.onPlay('" + id + "')");
                } catch (Exception e) {
                    Toast.makeText(act, "Could not play this recording", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @JavascriptInterface
    public void shareRec(final String id) {
        ui(new Runnable() {
            @Override
            public void run() {
                try {
                    Uri u = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, Long.parseLong(id));
                    Intent s = new Intent(Intent.ACTION_SEND);
                    s.setType("audio/mp4");
                    s.putExtra(Intent.EXTRA_STREAM, u);
                    s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    act.startActivity(Intent.createChooser(s, "Share recording"));
                } catch (Exception e) {
                    Toast.makeText(act, "Could not share this recording", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @JavascriptInterface
    public void deleteRec(final String id) {
        ui(new Runnable() {
            @Override
            public void run() {
                try {
                    long l = Long.parseLong(id);
                    if (playingId == l) stopPlayer();
                    act.getContentResolver().delete(ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, l), null, null);
                } catch (Exception e) {
                    Toast.makeText(act, "Could not delete", Toast.LENGTH_SHORT).show();
                }
                js("window.onRecs&&window.onRecs()");
            }
        });
    }

    @JavascriptInterface
    public void hold(final boolean on) {
        ui(new Runnable() {
            @Override
            public void run() {
                CallManager.hold(on);
            }
        });
    }

    @JavascriptInterface
    public void dtmf(final String s) {
        if (s == null || s.isEmpty()) return;
        ui(new Runnable() {
            @Override
            public void run() {
                CallManager.dtmf(s.charAt(0));
            }
        });
    }

    @JavascriptInterface
    public void close() {
        ui(new Runnable() {
            @Override
            public void run() {
                act.finish();
            }
        });
    }
}
