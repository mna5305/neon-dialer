# Neon Dialer (own phone app + own calling screen)

## What you get
- A real Android phone app that can become your DEFAULT dialer.
- Keypad, recents (real call history), contacts (real phone contacts), favorites, speed dial.
- Call recording (Record button on the call screen, Records tab, optional Auto-record).
- Your OWN calling screen (incoming / outgoing / active / hold / call-waiting / DTMF keypad).

## Files you can edit (plain HTML + CSS)
- `android/app/src/main/assets/incall.html`  -> the CALLING SCREEN (colors, layout, animations)
- `android/app/src/main/assets/index.html`   -> the dialer (keypad, recents, contacts)

## Build the APK (GitHub Actions)
1. Create a new GitHub repository.
2. Upload EVERYTHING from this folder (including the hidden `.github` folder).
3. Open the Actions tab -> "Build Android APK" runs automatically.
4. When it finishes, open the run and download the artifact `neon-dialer-apk`.
5. Unzip it and install `app-debug.apk` on your phone.

## First run on the phone
1. Open the app -> tap Allow (contacts, call history, phone).
2. Tap "Set default" -> choose Neon Dialer as your Phone app.
3. Settings (gear) -> Calling screen -> pick a style / color -> Preview incoming / outgoing.

If the build fails, copy the red error lines from the Actions log and send them.

## Call recording notes
- Android does not let normal apps capture the other person's voice directly, so recording uses the microphone. Turn on Speaker during the call to capture both voices.
- Files are saved in Music > CallRecordings (Android 10+). The Records tab can play, share and delete them.
- Recording laws differ by country. Only record with the other person's consent.
